"""
-------------------------------------------------------
Assignment 1 Task 1
-------------------------------------------------------
Author:  Ryan Chisholm
ID:      169027577
Email:   chis7577@mylaurier.ca
__updated__ = "2022-09-26"
-------------------------------------------------------
"""
# Imports

# Constants
    
print("""The book title is, "Learn Python in 21 Days" """)
print("What's mine is mine, and what's your is mine.")
print(''' "You have enemies? Good. That means you've stood up for something, sometime in your life." Winston Churchill''')
print('Three things cannot be long hidden: the sun, the moon and the truth.')
    
    
