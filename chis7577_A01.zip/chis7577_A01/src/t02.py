"""
-------------------------------------------------------
Assignment 1 Task 2
-------------------------------------------------------
Author:  Ryan Chisholm
ID:      169027577
Email:   chis7577@mylaurier.ca
__updated__ = "2022-09-26"
-------------------------------------------------------
"""
# Imports

# Constants
    
fav_food = str(input("Enter your favourite food: ")) #input for favourite food
TV_Show = str(input("Enter your favourite TV show: ")) #input for favourite TV Show
print(f"I like eating {fav_food} while watching {TV_Show}")    
    
